//
//  PlayerVolumeBoostView.swift
//  VolumeBooster
//
//  Created by Taras Chernysh on 17.07.2024.
//

import SwiftUI

struct PlayerVolumeBoostView: View {
    
    var body: some View {
        Rectangle().fill(Color.red)
    }
}
