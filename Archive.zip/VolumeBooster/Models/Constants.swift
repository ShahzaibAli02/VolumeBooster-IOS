//
//  Constants.swift
//  VolumeBooster
//
//  Created by Taras Chernysh on 07.07.2024.
//

import Foundation

enum Constants {
    
    static let termsOfUse = "https://www.apple.com"
    static let privacyPolicy = "https://www.apple.com"
}
