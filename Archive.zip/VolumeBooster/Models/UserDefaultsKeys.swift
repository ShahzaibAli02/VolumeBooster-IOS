//
//  UserDefaultsKeys.swift
//  VolumeBooster
//
//  Created by Taras Chernysh on 07.07.2024.
//

import Foundation

enum UserDefaultsKeys {
    static let isFinishedOnboarding = "isFinishedOnboarding"
}
